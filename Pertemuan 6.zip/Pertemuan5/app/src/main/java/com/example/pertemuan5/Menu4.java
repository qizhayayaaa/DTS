package com.example.pertemuan5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Menu4 extends AppCompatActivity {
    EditText Edt2;
    TextView Tv2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu4);

        Edt2 = findViewById(R.id.Edt2);
        Tv2 = findViewById(R.id.Tv2);
    }

    public void Hitung_Akar(View v){
        String hasil = Edt2.getText().toString();
        int akar = Integer.parseInt(hasil);

        int x = 1;
        int y = x * x;

        while (y != akar){
            x++;
            y = x * x;
        }
        Tv2.setText("Hasil akar dari " + hasil + " adalah " + x);
    }
}
